const express = require('express');
const { createPost, getPosts } = require('../controllers/postController');
const router = express.Router();

// Route for creating a new post
router.post('/', createPost);

// Route for fetching all posts
router.get('/', getPosts);

module.exports = router;
