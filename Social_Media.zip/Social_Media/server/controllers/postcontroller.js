const Post = require('../models/Post');  // Import the Post model

// Create a new post
exports.createPost = async (req, res) => {
  const { content } = req.body;
  const { userId } = req.user;  // Assuming the user is authenticated and userId is passed in the request

  // Validate content
  if (!content) {
    return res.status(400).json({ message: 'Post content is required' });
  }

  try {
    // Create a new post
    const newPost = new Post({
      userId,
      content,
    });

    await newPost.save();
    res.status(201).json({ message: 'Post created successfully', post: newPost });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all posts
exports.getAllPosts = async (req, res) => {
  try {
    const posts = await Post.find().populate('userId', 'name email');  // Populate user info for each post
    res.json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
