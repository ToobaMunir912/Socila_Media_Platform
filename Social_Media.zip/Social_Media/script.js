// JavaScript to handle button clicks for interactions
document.querySelectorAll('.like-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        alert('You liked this post!');
    });
});

document.querySelectorAll('.comment-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const comment = prompt('Enter your comment:');
        if (comment) {
            const postComments = this.closest('.post').querySelector('.comments-section');
            const newComment = document.createElement('div');
            newComment.classList.add('comment');
            newComment.innerHTML = `<p><strong>You:</strong> ${comment}</p>`;
            postComments.appendChild(newComment);
        }
    });
});

document.querySelectorAll('.share-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        alert('Post shared successfully!');
    });
});
